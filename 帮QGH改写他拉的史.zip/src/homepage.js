var password=0,username=" ";
var tnmpass,tnmus;
var command1=prompt("LOG OR REG");
do{
if(command1 =="LOG")
{
    do{
        tnmus=prompt("username");
        tnmpass=prompt("password");               
        if(tnmpass!=password&tnmus!=username)
            alert("name or pass is false! Try again")
    
    }while(tnmpass==password & tnmus==username)
    alert("login success")
}
else if(command1 == "REG")
{
    do{
        tnmus=prompt("username");
        tnmpass=prompt("password");               
        if(tnmpass!=password&tnmus!=username)
            alert("name or pass is false! Try again")
    
    }while(tnmpass==password & tnmus==username)
    username=prompt("username");
    password=prompt("password");
    
}

}while(command1 != "LOG" | "REG")